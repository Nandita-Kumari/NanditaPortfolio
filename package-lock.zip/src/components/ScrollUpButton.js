import React from 'react';

const ScrollUpButton = () => {
  return (
    <div className="scroll-up-btn">
      <i className="fas fa-angle-up"></i>
    </div>
  );
};

export default ScrollUpButton;